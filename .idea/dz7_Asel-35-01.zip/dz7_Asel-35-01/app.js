const buttonShow= document.querySelector('.btn')
const answer = document.querySelector('span')

function showAnswer (){
    answer.classList.toggle('hide')
    buttonShow.innerHTML='Скрыть ответ'
}

buttonShow.onclick=()=> showAnswer()
